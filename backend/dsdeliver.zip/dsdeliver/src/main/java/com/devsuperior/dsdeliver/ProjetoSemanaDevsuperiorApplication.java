package com.devsuperior.dsdeliver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSemanaDevsuperiorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSemanaDevsuperiorApplication.class, args);
	}

}
